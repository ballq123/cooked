#!/bin/bash

zip -FSr assgn3.zip . -x ".*" -x "__MACOSX" -x "*Icon*" -x "zip_.sh"
