#!/bin/bash

zip -FSr soln1.zip . -x ".*" -x "__MACOSX" -x "*Icon*" -x "assgn1.pdf"
