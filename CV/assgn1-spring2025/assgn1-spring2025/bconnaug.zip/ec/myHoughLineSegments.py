def myHoughLineSegments(lineRho, lineTheta, Im):
  # YOUR CODE HERE